Am rulat unittesturile create cu comanda python3 -m unittest unittests/TestWebserver.py.
Am avut urmatorul output:
........got data in post {'test_key': 'test_value'}
.......
----------------------------------------------------------------------
Ran 15 tests in 1.879s

OK

Mesajul acela cu "got data in ...." este afisat acolo deoarece in routes.py in 
/api/post_endpoint

